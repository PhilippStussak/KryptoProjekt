/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kryptoprojekt.model;

/**
 *
 * @author Michael
 */
import java.util.*;

public class Luca {

     Luca(Collection<Tuple<ArrayList<Z> , ArrayList<Z>>> primeFactorsCollection){

     }
     /*
     Luca(Collection<Triple<Collection<Z> , Collection<Z>, Collection<Z>>> primeFactorsCollection){

     }*/

}
