README
======

Installation
------------
Zum Installieren die Setup.exe ausf�hren und auf "OK" klicken. 
Danach kann das Programm durch ausf�hren der start.bat gestartet werden.